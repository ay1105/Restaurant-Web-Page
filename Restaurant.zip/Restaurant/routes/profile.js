const express = require("express");
const router = express.Router();
const profileController = require("../controllers/profileController");

// Serve the profile page
router.get("/", profileController.getProfilePage);

// Fetch profile data
router.get("/data", profileController.getProfileData);

module.exports = router;