const express = require('express');
const router = express.Router();
const nonvegController = require('../controllers/nonvegController');

// Veg category route
router.get('/nonveg', nonvegController.getnonVegItems);

module.exports = router;