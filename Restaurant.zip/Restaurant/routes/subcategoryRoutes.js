const express = require("express");
const router = express.Router();

// Subcategories data (vegetarian and non-vegetarian categories)
const subcategories = {
  veg: ["Starter", "Main Course", "Dessert"],
  "non-veg": ["Starter", "Main Course", "Grill", "Curry"],
};

// Route to get subcategories based on category
router.get("/subcategories/:category", (req, res) => {
  const { category } = req.params;

  // Check if the category exists in subcategories
  if (subcategories[category]) {
    res.status(200).json({ subcategories: subcategories[category] });
  } else {
    res.status(404).json({ message: "Category not found" });
  }
});

module.exports = router