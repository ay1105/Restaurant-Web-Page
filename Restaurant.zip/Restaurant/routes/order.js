const express = require("express");
const Order = require("../models/order");
const router = express.Router();

// Fetch all confirmed orders
router.get("/orders", async (req, res) => {
    try {
        const orders = await Order.find({ status: "confirmed" }).populate("userDetails");
        res.json(orders);
    } catch (error) {
        console.error("Error fetching orders:", error);
        res.status(500).send("Error fetching orders.");
    }
});

module.exports = router;