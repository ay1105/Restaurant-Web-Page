const express = require('express');
const router = express.Router();
const desertController = require('../controllers/desertController');

// Veg category route
router.get('/desert', desertController.getdesert);

module.exports = router;