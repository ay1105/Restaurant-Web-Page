const express = require('express');
const router = express.Router();
const TableReservation = require('../models/reservationmodel');

// Route to add new reservation slots (Admin side)
router.post('/addSlots', async (req, res) => {
    const { date, slots } = req.body;

    if (!slots || !Array.isArray(slots) || slots.length === 0) {
        return res.status(400).json({ message: 'Invalid slots data' });
    }

    try {
        let reservation = await TableReservation.findOne({ date });

        if (!reservation) {
            reservation = new TableReservation({
                date,
                slots: slots.map(slot => ({
                    startTime: slot.startTime,
                    tables: slot.tables.map(table => ({
                        tableNumber: table.tableNumber,
                        totalSeats: table.totalSeats,
                        availableSeats: table.availableSeats,
                        reservedSeats: 0
                    }))
                }))
            });
        } else {
            slots.forEach(slot => {
                reservation.slots.push({
                    startTime: slot.startTime,
                    tables: slot.tables.map(table => ({
                        tableNumber: table.tableNumber,
                        totalSeats: table.totalSeats,
                        availableSeats: table.availableSeats,
                        reservedSeats: 0
                    }))
                });
            });
        }

        await reservation.save();
        res.status(200).json({ message: 'Slots added successfully!' });
    } catch (error) {
        res.status(500).json({ message: 'Error adding slots', error: error.message });
    }
});

module.exports = router;
