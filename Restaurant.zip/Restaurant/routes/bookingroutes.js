const express = require('express');
const router = express.Router();
const bookingController = require('../controllers/bookingController');

// Route to book a slot
router.post('/book-slot', bookingController.bookSlot);



// GET available slots for a specific date
router.get("/available-slots/:date", bookingController.getAvailableSlots);

module.exports = router;

