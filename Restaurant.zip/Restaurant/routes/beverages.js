const express = require('express');
const router = express.Router();
const beveragesController = require('../controllers/beveragesController');

// Veg category route
router.get('/beverages', beveragesController.getbeverages);

module.exports = router;