const express = require('express');
const router = express.Router();
const vegController = require('../controllers/vegController');

// Veg category route
router.get('/veg', vegController.getVegItems);

module.exports = router;