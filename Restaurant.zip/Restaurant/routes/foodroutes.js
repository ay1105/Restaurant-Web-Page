const express = require("express");
const router = express.Router();
const { addFood, getFoodItems, deleteFood } = require("../Controllers/foodcontroller");

// Route to add food item (POST request)
router.post("/", addFood);

// Route to get all food items (GET request)
router.get("/", getFoodItems);

// Route to delete food item (DELETE request)
router.delete("/:id", deleteFood);

module.exports = router;
