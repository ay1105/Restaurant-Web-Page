const express = require("express");
const path = require("path");
const router = express.Router();
const authController = require("../controllers/authController");

// Routes for authentication
router.get("/admin", (req, res) => res.sendFile(path.join(__dirname, "../public/admin.html")));
router.get("/login", authController.getLoginPage);
router.get("/signup", authController.getSignupPage);
router.post("/signup", authController.postSignup);
router.post("/login", authController.postLogin);
router.get("/logout", authController.getLogout);

module.exports = router;