document.addEventListener("DOMContentLoaded", () => {
    const token = localStorage.getItem("token");

    if (!token) {
        alert("You are not logged in!");
        window.location.href = "/auth/login";
        return;
    }

    // Fetch user profile
    fetch("/auth/profile", {
        method: "GET",
        headers: {
            Authorization: `Bearer ${token}`,
        },
    })
        .then(response => response.json())
        .then(user => {
            if (user.message) {
                alert(user.message);
                window.location.href = "/auth/login";
                return;
            }

            document.getElementById("profile").innerHTML = `
                <p><strong>Username:</strong> ${user.username}</p>
                <p><strong>Email:</strong> ${user.email}</p>
                <p><strong>Role:</strong> ${user.role}</p>
                <button id="logoutBtn">Logout</button>
            `;

            // Logout functionality
            document.getElementById("logoutBtn").addEventListener("click", () => {
                localStorage.removeItem("token");  // Remove token from storage
                alert("Logged out successfully.");
                window.location.href = "/auth/login";
            });
        })
        .catch(error => {
            console.error("Error fetching profile:", error);
            alert("Error loading profile. Please try again.");
        });
});

