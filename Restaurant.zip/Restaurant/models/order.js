const mongoose = require("mongoose");

const orderSchema = new mongoose.Schema({
    userDetails: {
        fullName: String,
        email: String,
        phone: String,
        address: String,
    },
    cart: [
        {
            name: String,
            quantity: Number,
            price: Number,
            image: String,
        },
    ],
    totalPrice: Number,
    status: {
        type: String,
        default: "confirmed",
    },
    createdAt: {
        type: Date,
        default: Date.now,
    },
});

module.exports = mongoose.model("Order", orderSchema);