const mongoose = require("mongoose");

const userSchema = new mongoose.Schema({
    username: {
        type: String,
        required: true,
        validate: {
            validator: function (v) {
                return /^[A-Za-z\s]+$/.test(v); // Only characters and spaces
            },
            message: props => `${props.value} is not a valid name. Only letters are allowed.`
        }
    },
    email: {
        type: String,
        required: true,
        unique: true,
        validate: {
            validator: function (v) {
                return /^[A-Za-z][A-Za-z0-9._]*@gmail\.com$/.test(v); // Must not start with number & ends with @gmail.com
            },
            message: props => `${props.value} is not a valid Gmail address.`
        }
    },
    password: { 
        type: String, 
        required: true 
    },
    phone: {
        type: String,
        required: true,
        unique: true,
        validate: {
            validator: function (v) {
                return /^[789]\d{9}$/.test(v); // Starts with 7/8/9 and has 10 digits
            },
            message: props => `${props.value} is not a valid phone number. It must start with 7, 8, or 9 and be 10 digits.`
        }
    },
    address: { 
        type: String, 
        required: true 
    },
    role: { 
        type: String, 
        default: "user" 
    }
});

const User = mongoose.model("User", userSchema);

module.exports = User;
