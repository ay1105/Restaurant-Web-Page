const mongoose = require('mongoose');

const TableSchema = new mongoose.Schema({
    tableNumber: Number,
    totalSeats: Number,
    availableSeats: Number,
    reservedSeats: { type: Number, default: 0 }
});

const SlotSchema = new mongoose.Schema({
    startTime: String,
    tables: [TableSchema]
});

const ReservationSchema = new mongoose.Schema({
    date: { type: String, required: true, unique: true }, // Changed to string to prevent MongoDB Date mismatches
    slots: [SlotSchema]
});

module.exports = mongoose.model('TableReservation', ReservationSchema);

