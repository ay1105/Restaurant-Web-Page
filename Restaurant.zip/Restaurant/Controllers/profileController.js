const User = require("../models/user");
const jwt = require("jsonwebtoken");
const path = require("path");

const JWT_SECRET = "26d576848529511aa81a7787e4c454d433c983c34d222053a11be876d1a329ded715644fe8ca975a4c3fd1ab1e94f8ece95fdddfb7a9e1ac62c149c8fa3e9c7a"; // Store securely in an env file

// Serve the profile page
const getProfilePage = async (req, res) => {
    try {
        res.sendFile(path.join(__dirname, "../public/profile.html"));
    } catch (error) {
        console.error("Error loading profile page:", error);
        res.status(500).send("Server error");
    }
};

// Fetch profile data
const getProfileData = async (req, res) => {
    try {
        const token = req.headers.authorization?.split(" ")[1];

        if (!token) {
            return res.status(401).json({ error: "Unauthorized. Please log in." });
        }

        // Verify the token
        const decoded = jwt.verify(token, JWT_SECRET);
        const user = await User.findById(decoded.userId).select("-password"); // Exclude password

        if (!user) {
            return res.status(404).json({ error: "User not found." });
        }

        res.json(user);
    } catch (error) {
        console.error("Profile error:", error);
        res.status(500).json({ error: "Error fetching profile. Please try again." });
    }
};

module.exports = {
    getProfilePage,
    getProfileData,
};