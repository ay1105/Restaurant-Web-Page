const Food = require('../models/food');

exports.getVegItems = async (req, res) => {
    try {
        const vegItems = await Food.find({ category: "veg" });

        if (!vegItems || vegItems.length === 0) {
            return res.status(404).json({ message: "No Veg Items Found" });
        }

        res.json(vegItems);
    } catch (error) {
        console.error("Error fetching veg items:", error);
        res.status(500).json({ error: "Failed to fetch veg items" });
    }
};