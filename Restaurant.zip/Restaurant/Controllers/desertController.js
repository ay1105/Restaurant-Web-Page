const Food = require('../models/food');

exports.getdesert = async (req, res) => {
    try {
        const desert = await Food.find({ category: "desert" });

        if (!desert || desert.length === 0) {
            return res.status(404).json({ message: "No desert Found" });
        }

        res.json(desert);
    } catch (error) {
        console.error("Error fetching desert:", error);
        res.status(500).json({ error: "Failed to fetch desert" });
    }
};