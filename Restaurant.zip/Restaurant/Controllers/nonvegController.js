const Food = require('../models/food');

exports.getnonVegItems = async (req, res) => {
    try {
        const nonvegItems = await Food.find({ category: "non-veg" });

        if (!nonvegItems || nonvegItems.length === 0) {
            return res.status(404).json({ message: "No nonVeg Items Found" });
        }

        res.json(nonvegItems);
    } catch (error) {
        console.error("Error fetching nonveg items:", error);
        res.status(500).json({ error: "Failed to fetch nonveg items" });
    }
};