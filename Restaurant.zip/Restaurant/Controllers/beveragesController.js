const Food = require('../models/food');

exports.getbeverages = async (req, res) => {
    try {
        const beverages = await Food.find({ category: "beverages" });

        if (!beverages || beverages.length === 0) {
            return res.status(404).json({ message: "No beverages Found" });
        }

        res.json(beverages);
    } catch (error) {
        console.error("Error fetching beverages:", error);
        res.status(500).json({ error: "Failed to fetch beverages" });
    }
};