const bcrypt = require("bcrypt");
const jwt = require("jsonwebtoken");
const User = require("../models/user");
const path = require("path");

const JWT_SECRET = "26d576848529511aa81a7787e4c454d433c983c34d222053a11be876d1a329ded715644fe8ca975a4c3fd1ab1e94f8ece95fdddfb7a9e1ac62c149c8fa3e9c7a"; // Replace with a secure key

// Display Login Page
const getLoginPage = (req, res) => {
    res.sendFile(path.join(__dirname, "../public/login.html"));
};

// Display Signup Page
const getSignupPage = (req, res) => {
    res.sendFile(path.join(__dirname, "../public/signup.html"));
};

// Handle Signup Form Submission
const postSignup = async (req, res) => {
    try {
        const { username, email, password, phone, address,role } = req.body;

        // Hash the password
        const hashedPassword = await bcrypt.hash(password, 10);

        // Create a new user (role defaults to "user" if not provided)
        const user = new User({
            username,
            email,
            password: hashedPassword,
            phone,
            address,
            role: role || "user"
        });

        await user.save();
        res.redirect("/auth/login");
    } catch (error) {
        console.error("Signup error:", error);
        res.status(500).send("Error signing up. Please try again.");
    }
};

// Handle Login Form Submission
const postLogin = async (req, res) => {
    try {
        const { email, password } = req.body;

        // Find the user by email
        const user = await User.findOne({ email });

        if (!user) {
            return res.status(401).send("Invalid email or password.");
        }

        // Compare the password
        const isMatch = await bcrypt.compare(password, user.password);

        if (!isMatch) {
            return res.status(401).send("Invalid email or password.");
        }

        // Generate a JWT token
        const token = jwt.sign({ userId: user._id, email: user.email, role: user.role }, JWT_SECRET, { expiresIn: "1h" });

        // Redirect to profile page and send the token
        res.send(`
            <script>
                localStorage.setItem('token', '${token}');
                window.location.href = '/index.html';
            </script>
        `);
    } catch (error) {
        console.error("Login error:", error);
        res.status(500).send("Error logging in. Please try again.");
    }
};

// Handle Logout
const getLogout = (req, res) => {
    res.send(`
        <script>
            localStorage.removeItem('token');
            window.location.href = '/auth/login';
        </script>
    `);
};

module.exports = {
    getLoginPage,
    getSignupPage,
    postSignup,
    postLogin,
    getLogout,
};