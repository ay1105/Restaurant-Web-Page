const Food = require("../models/food");

// POST endpoint to add food item
exports.addFood = async (req, res) => {
    try {
        console.log("Received food data:", req.body); // Debugging

        const { name, category, subcategory, price, photo } = req.body;

        // Basic Validation
        if (!name || !category || !price || !photo) {
            return res.status(400).json({ error: "All fields are required" });
        }

        // Create a new food item
        const newFood = new Food({
            name,
            category,
            subcategory,
            price,
            photo
        });

        // Save to database
        const savedFood = await newFood.save();
        res.status(201).json(savedFood);
    } catch (error) {
        console.error("Error saving food:", error);
        res.status(500).json({ error: "Internal Server Error" });
    }
};
// GET endpoint to fetch all food items
exports.getFoodItems = async (req, res) => {
    try {
        const foodItems = await Food.find(); // Fetch all food items from the DB
        res.json(foodItems);
    } catch (error) {
        res.status(500).json({ message: "Error fetching food items", error });
    }
};

// DELETE endpoint to remove a food item
exports.deleteFood = async (req, res) => {
    try {
        const { id } = req.params;
        console.log("Received ID:", id); // Debugging log

        if (!id || id === "undefined") {
            return res.status(400).json({ message: "Invalid food ID" });
        }

        // Check if the ID exists before deleting
        const existingFood = await Food.findById(id);
        if (!existingFood) {
            return res.status(404).json({ message: "Food item not found" });
        }

        await Food.findByIdAndDelete(id);
        
        const foodItems = await Food.find();
        res.json(foodItems);
    } catch (error) {
        console.error("Error deleting food item:", error);
        res.status(500).json({ message: "Error deleting food item", error });
    }
};
