const TableReservation = require('../models/reservationmodel');

// Book a slot
exports.bookSlot = async (req, res) => {
    try {
        const { name, phone, date, time, people } = req.body;
        console.log("Booking request received:", { name, phone, date, time, people }); // Debugging

        if (!name || !phone || !date || !time || !people) {
            return res.status(400).json({ message: "All fields are required." });
        }

        const selectedDate = new Date(date);
        selectedDate.setUTCHours(0, 0, 0, 0);
        console.log("Parsed date:", selectedDate); // Debugging

        // Find or create a reservation for the selected date
        let reservation = await TableReservation.findOne({ date: selectedDate });
        console.log("Reservation found:", reservation); // Debugging

        if (!reservation) {
            console.log("No reservations found, creating new one..."); // Debugging
            reservation = new TableReservation({
                date: selectedDate,
                slots: [], // Initialize with no slots
            });
        }

        // Find or create a slot for the selected time
        let slot = reservation.slots.find(slot => slot.startTime === time);
        console.log("Slot found:", slot); // Debugging

        if (!slot) {
            console.log("No slot found, creating new one..."); // Debugging
            slot = { startTime: time, tables: [] };
            reservation.slots.push(slot);
        }

        // Find a table with enough available seats
        let table = slot.tables.find(t => t.availableSeats >= people);
        console.log("Table found:", table); // Debugging

        // If no suitable table is found, create a new table
        if (!table) {
            console.log("No available table found, adding a new table..."); // Debugging
            table = {
                tableNumber: slot.tables.length + 1, // Assign the next table number
                totalSeats: 8, // Default table size
                availableSeats: 8, // Initialize with all seats available
                reservedSeats: 0, // Initialize with no reserved seats
            };
            slot.tables.push(table); // Add the new table to the slot
        }

        // Check if there are enough available seats
        if (table.availableSeats < people) {
            return res.status(400).json({ message: "Not enough seats available." });
        }

        // Deduct the seats and update reserved seats
        table.availableSeats -= people;
        table.reservedSeats += people;
        console.log("Updated table:", table); // Debugging

        // Save the reservation
        await reservation.save();
        console.log("Reservation saved:", reservation); // Debugging

        return res.status(200).json({ message: `Slot booked successfully! Table ${table.tableNumber} assigned.` });
    } catch (error) {
        console.error("Error booking slot:", error);
        return res.status(500).json({ message: "Server error. Please try again." });
    }
};

// GET available slots for a specific date (user-side)
exports.getAvailableSlots = async (req, res) => {
    try {
        const { date } = req.params;
        if (!date) {
            return res.status(400).json({ message: "Date is required." });
        }

        // Parse selected date in UTC format (ignoring time)
        const selected = new Date(date);
        const selectedDate = new Date(Date.UTC(
            selected.getUTCFullYear(),
            selected.getUTCMonth(),
            selected.getUTCDate()
        ));

        // Get today's date in UTC format (ignoring time)
        const today = new Date();
        const currentDate = new Date(Date.UTC(
            today.getUTCFullYear(),
            today.getUTCMonth(),
            today.getUTCDate()
        ));

        // 🚫 Block past dates
        if (selectedDate < currentDate) {
            return res.status(400).json({ message: "Cannot view or book past dates." });
        }

        // Query for reservations on the selected date
        let reservation = await TableReservation.findOne({
            $or: [
                { date: selectedDate },
                { date: date }
            ]
        });

        if (!reservation) {
            return res.status(404).json({ message: "No slots available for this date." });
        }

        // Filter only slots that have available seats
        const availableSlots = reservation.slots
            .filter(slot => slot.tables.some(table => table.availableSeats > 0))
            .map(slot => ({
                startTime: slot.startTime,
                availableSeats: slot.tables.reduce((total, table) => total + table.availableSeats, 0),
            }));

        return res.status(200).json({ availableSlots });
    } catch (error) {
        console.error("Error retrieving available slots:", error);
        return res.status(500).json({ message: "Server error. Please try again." });
    }
};

